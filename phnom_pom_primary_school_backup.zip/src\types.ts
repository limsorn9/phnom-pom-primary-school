export type Gender = 'M' | 'F';
export type LivingCondition = 'ទូទៅ' | 'ក្រ១' | 'ក្រ២' | string;
export type AcademicHistoryStatus = 'ឡើងថ្នាក់' | 'ត្រួតថ្នាក់' | 'ចូលរៀនឡើងវិញ' | 'ផ្ទេរចូល' | string;
export type OrphanStatus = 'មិនកំព្រា' | 'កំព្រាឪពុក' | 'កំព្រាម្តាយ' | 'កំព្រាទាំងពីរ' | string;

export interface HealthRecord {
  heightCm: number;
  weightKg: number;
  bmi: number;
  nutritionStatus: 'normal' | 'underweight' | 'overweight' | 'wasted';
  vaccinated: boolean;
  bloodType: string;
  notes?: string;
  lastCheckedDate: string;
}

export interface AttendanceSummary {
  present: number;
  absentWithPermission: number;
  absentWithoutPermission: number;
  totalDays: number;
}

export interface Student {
  id: string;
  code: string; // អត្តលេខសិស្ស e.g., "STU-2024-001"
  nameKhmer: string; // គោត្តនាម-នាម
  lastNameKhmer?: string; // គោត្តនាម
  firstNameKhmer?: string; // នាម
  nameLatin: string; // គោត្តនាមឡាតាំង-នាមឡាតាំង
  lastNameLatin?: string; // គោត្តនាមឡាតាំង
  firstNameLatin?: string; // នាមឡាតាំង
  gender: Gender; // ភេទ
  dob: string; // ថ្ងៃខែឆ្នាំកំណើត (YYYY-MM-DD)
  age?: number; // អាយុ
  pob: string; // ទីកន្លែងកំណើតរួម
  pobVillage?: string; // ភូមិកំណើត
  pobCommune?: string; // ឃុំកំណើត
  pobDistrict?: string; // ស្រុកកំណើត
  pobProvince?: string; // ខេត្តកំណើត
  grade: number; // 1 to 6 (ថ្នាក់ទី)
  section: string; // 'ក' | 'ខ' | 'គ' (បន្ទប់)
  
  // Family Details (ព័ត៌មានគ្រួសារ)
  fatherLastName?: string; // គោត្តនាមឪពុក
  fatherFirstName?: string; // នាមឪពុក
  fatherName?: string; // ឈ្មោះឪពុកពេញ
  fatherOccupation?: string; // មុខរបរឪពុក
  motherLastName?: string; // គោត្តនាមម្តាយ
  motherFirstName?: string; // នាមម្តាយ
  motherName?: string; // ឈ្មោះម្តាយពេញ
  motherOccupation?: string; // មុខរបរម្តាយ
  guardianLastName?: string; // គោត្តនាមអាណាព្យាបាល
  guardianFirstName?: string; // នាមអាណាព្យាបាល
  guardianName: string; // គោត្តនាមអាណាព្យាបាល-នាមអាណាព្យាបាល
  guardianRelationship: string; // ទំនាក់ទំនង (ឪពុក ម្តាយ ជីដូន ជីតា អាណាព្យាបាល)
  guardianPhone: string; // លេខទូរស័ព្ទអាណាព្យាបាល
  guardianOccupation: string; // មុខរបរអាណាព្យាបាល
  
  // Current Address & Status (អាសយដ្ឋានបច្ចុប្បន្ន និងស្ថានភាព)
  address: string; // អាសយដ្ឋានបច្ចុប្បន្នរួម
  currentHouseNumber?: string; // ផ្ទះលេខ
  currentStreetNumber?: string; // ផ្លូវលេខ
  currentVillage?: string; // ភូមិបច្ចុប្បន្ន
  currentCommune?: string; // ឃុំបច្ចុប្បន្ន
  currentDistrict?: string; // ស្រុកបច្ចុប្បន្ន
  currentProvince?: string; // ខេត្តបច្ចុប្បន្ន
  academicHistory?: string; // ប្រវត្តិសិក្សា (ឡើងថ្នាក់, ត្រួតថ្នាក់, ចូលរៀនឡើងវិញ...)
  livingCondition?: string; // ជីវភាព (ក្រ១ / ក្រ២ / សមរម្យ / ទូទៅ)
  idPoorCardNumber?: string; // លេខប័ណ្ណក្រីក្រ
  isOrphan?: string; // កំព្រា (គ្មាន / កំព្រាឪពុក / កំព្រាម្តាយ / កំព្រាទាំងពីរ)
  orphanStatus?: string; // ស្ថានភាពកំព្រា
  isDisability?: boolean | string; // ពិការ
  disability?: string; // ពិការភាពលម្អិត
  disabilityDetail?: string; // ព័ត៌មានលម្អិតពិការភាព
  hasScholarship?: boolean | string; // អាហារូបករណ៍
  scholarship?: string; // អាហារូបករណ៍
  scholarshipDetail?: string;
  isEthnicMinority?: boolean | string; // ជនជាតិដើមភាគតិច
  ethnicMinority?: string; // ជនជាតិ
  ethnicGroup?: string;
  specialCharacteristics?: string; // លក្ខណៈពិសេស / ទេពកោសល្យ
  phone?: string; // លេខទូរស័ព្ទផ្ទាល់
  previousSchool?: string; // មកពីសាលា
  academicYear?: string; // ឆ្នាំសិក្សា
  admissionDate: string; // ថ្ងៃចូលរៀន
  status: 'active' | 'transferred' | 'dropped' | 'graduated'; // ស្ថានភាពសិស្ស
  remarks?: string; // ផ្សេងៗ
  fatherAlive?: boolean; // ឪពុកនៅរស់
  motherAlive?: boolean; // ម្តាយនៅរស់
  avatarUrl?: string; // រូបថតសិស្ស
  health: HealthRecord;
  attendance: AttendanceSummary;
}

export interface DutyScheduleItem {
  day: 'ចន្ទ' | 'អង្គារ' | 'ពុធ' | 'ព្រហស្បតិ៍' | 'សុក្រ' | 'សៅរ៍';
  subject: string;
  timeSlot: string;
  gradeClass: string;
}

export interface Teacher {
  id: string;
  staffCode: string; // អត្តលេខមន្ត្រីរាជការ
  nameKhmer: string; // គោត្តនាម និងនាម
  lastNameKhmer?: string; // គោត្តនាម
  firstNameKhmer?: string; // នាម
  nameLatin: string; // គោត្តនាមឡាតាំង និងនាមឡាតាំង
  gender: Gender; // ភេទ
  dob: string; // ថ្ងៃខែឆ្នាំកំណើត
  nationality?: string; // សញ្ជាតិ (ខ្មែរ)
  ethnicity?: string; // ជនជាតិ (ខ្មែរ / ផ្សេងៗ)
  disabilityStatus?: string; // ពិការភាព
  
  // Addresses & Contacts (ទីលំនៅ និងទំនាក់ទំនង)
  phone: string; // លេខទូរស័ព្ទ
  email: string; // អ៊ីម៉ែល
  nationalId?: string; // លេខអត្តសញ្ញាណប័ណ្ណ
  telegramPhone?: string; // លេខតេលេក្រាម
  pob?: string; // ទីកន្លែងកំណើត
  pobVillage?: string; // ភូមិកំណើត
  pobCommune?: string; // ឃុំកំណើត
  pobDistrict?: string; // ស្រុកកំណើត
  pobProvince?: string; // ខេត្តកំណើត
  currentAddress?: string; // អាសយដ្ឋានបច្ចុប្បន្ន
  currentHouseNumber?: string; // ផ្ទះលេខ
  currentStreetNumber?: string; // ផ្លូវលេខ
  currentVillage?: string; // ភូមិបច្ចុប្បន្ន
  currentCommune?: string; // ឃុំបច្ចុប្បន្ន
  currentDistrict?: string; // ស្រុកបច្ចុប្បន្ន
  currentProvince?: string; // ខេត្តបច្ចុប្បន្ន
  distanceToSchoolKm?: number; // ចម្ងាយទៅសាលា (គ.ម)
  
  // National ID Card (អត្តសញ្ញាណប័ណ្ណ)
  nationalIdNumber?: string; // លេខអត្តសញ្ញាណប័ណ្ណ
  nationalIdIssueDate?: string; // ថ្ងៃចេញ
  nationalIdExpiryDate?: string; // ថ្ងៃអស់សុពលភាព
  nationalIdPhotoUrl?: string; // រូបថតអត្តសញ្ញាណប័ណ្ណ
  
  // Professional Details (ព័ត៌មានវិជ្ជាជីវៈ និងក្របខ័ណ្ឌ)
  role: string; // តួនាទី (នាយក, នាយករង, គ្រូបន្ទុកថ្នាក់, គ្រូឯកទេស, បណ្ណារក្ស, លេខាធិការ)
  responsibilities?: string; // ភារកិច្ច
  startDate: string; // ថ្ងៃខែចូលបម្រើការងារ
  civilServiceEntryDate?: string; // ថ្ងៃតាំងស៊ប់ក្នុងក្របខណ្ឌ
  yearsOfService: number; // ចំនួនឆ្នាំបម្រើការងារ
  framework?: string; // ក្របខណ្ឌ
  civilServiceFramework?: string; // ក្របខ័ណ្ឌ (ឧ. ក្របខ័ណ្ឌគ្រូបឋម, ក្របខ័ណ្ឌមន្ត្រីរដ្ឋបាល)
  frameworkLevel?: string; // កម្រិតក្របខ័ណ្ឌ (ឧ. ក.១.១, ក.២, ខ.១)
  qualification: string; // សញ្ញាបត្រគ្រូ / គរុកោសល្យ
  specialization?: string; // ឯកទេស
  teachingSubject?: string; // មុខវិជ្ជាបង្រៀន
  appointmentLetterRef?: string; // លិខិតតែងតាំង / ប្រកាសលេខ
  salaryIndex?: string; // កាំប្រាក់
  specializedDegreeLevel?: string; // កម្រិតសញ្ញាបត្រឯកទេស
  schoolPostingDate?: string; // ថ្ងៃខែឆ្នាំទទួលគ្រឹះស្ថានសិក្សា
  pedagogicalTrainingCourse?: string; // វគ្គបណ្តុះបណ្តាលគរុកោសល្យ
  trainingCohort?: string; // វគ្គសិក្សា
  certificateDate?: string; // ថ្ងៃខែទទួលបាន
  schoolCode?: string; // លេខកូដសាលា
  assignedGrade?: number; // ថ្នាក់បង្រៀន
  assignedSection?: string; // បន្ទប់
  teachingShift?: string; // វេនបង្រៀន (ព្រឹក / រសៀល / ពេញមួយថ្ងៃ)
  totalClassesTaught?: number; // ថ្នាក់សរុប
  totalStudentsFemaleTaught?: number; // ស្រី (ស្ថិតិសិស្សស្រីបង្រៀន)
  
  // Banking, Health & Family (ធនាគារ សុខភាព និងគ្រួសារ)
  nssfNumber?: string; // បណ្ណ ស.ប.ស.ក (NSSF)
  bankAccountNumber?: string; // គណនីបៀវត្ស
  bankName?: string; // ឈ្មោះធនាគារ (កាណាឌីយ៉ា / អេស៊ីលីដា / វីង)
  parentsInfo?: string; // ឈ្មោះ និងមុខរបរឪពុកម្តាយ
  status: 'active' | 'on_leave' | 'transferred'; // ស្ថានភាពបច្ចុប្បន្ន
  vaccinated?: boolean; // បានចាក់វ៉ាក់សាំង
  vaccineName?: string; // ឈ្មោះវ៉ាក់សាំង
  lastVaccinatedDate?: string; // ថ្ងៃខែចាក់លើកចុងក្រោយ
  maritalStatus?: string; // ស្ថានភាពគ្រួសារ (នៅលីវ / រៀបការ / មេម៉ាយ / ពោះម៉ាយ)
  spouseName?: string; // ឈ្មោះប្តី/ប្រពន្ធ
  spouseOccupation?: string; // មុខរបរប្តី/ប្រពន្ធ
  spousePhone?: string; // លេខទូរស័ព្ទប្តី/ប្រពន្ធ
  spousePob?: string; // ទីកន្លែងកំណើតប្តី/ប្រពន្ធ
  spouseAddress?: string; // អាសយដ្ឋានបច្ចុប្បន្នប្តី/ប្រពន្ធ
  childrenCount?: number; // ចំនួនកូនក្នុងបន្ទុក
  child1Name?: string; // ឈ្មោះកូនទី១
  child2Name?: string; // ឈ្មោះកូនទី២
  child3Name?: string; // ឈ្មោះកូនទី៣
  documentsNote?: string; // ឯកសារ និងប្រភេទបណ្ណផ្សេងៗ
  avatarUrl?: string; // រូបថត
  schedule: DutyScheduleItem[];
}

export type TransferType = 'out' | 'in'; // ផ្ទេរចេញ | ផ្ទេរចូល
export type TransferStatus = 'approved' | 'pending' | 'completed' | 'rejected';

export interface ExamSubject {
  id: string;
  code: string;
  nameKhmer: string;
  nameLatin?: string;
  category: 'khmer' | 'math' | 'science_social' | 'arts_pe' | 'skills_language';
  maxScore: number;
  weight: number;
  isDefault?: boolean;
}

export interface ProfileEditRequest {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  targetType: 'teacher' | 'student' | 'user';
  targetId: string;
  requestedFields: Record<string, any>;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNotes?: string;
  oneTimeToken?: string;
  isUsed?: boolean;
}

export interface StudentTransferRecord {
  id: string;
  transferType: TransferType; // 'out' (លិខិតផ្ទេរសិស្សចេញ) | 'in' (បន្ថែមសិស្សចូល)
  letterNumber: string; // លេខលិខិតផ្ទេរ e.g. "លខ.០៤២/២០២៤"
  transferDate: string; // ថ្ងៃខែឆ្នាំផ្ទេរ
  studentId?: string;
  studentCode: string;
  studentNameKhmer: string;
  studentNameLatin: string;
  gender: Gender;
  dob: string;
  grade: number;
  section: string;
  academicYear: string;
  
  // School details
  fromSchool: string; // ផ្ទេរមកពីសាលា / សាលាដើម
  fromSchoolCode?: string;
  toSchool: string; // ផ្ទេរទៅកាន់សាលា
  toSchoolCode?: string;
  toDistrictProvince?: string; // ស្រុក/ខេត្ត គោលដៅ
  
  // Reason & Family
  reason: string; // មូលហេតុផ្ទេរ
  guardianName: string;
  guardianPhone: string;
  
  // Official approvals
  principalApprovalName: string; // នាយកសាលាអនុម័ត
  officerName: string; // មន្ត្រីរៀបចំ/លេខាធិការ
  status: TransferStatus;
  notes?: string;
}

export interface Classroom {
  id: string;
  grade: number;
  section: string;
  roomNumber: string;
  homeroomTeacherId: string;
  homeroomTeacherName: string;
  academicYear: string;
  capacity: number;
}

export interface MonthlySubjectScores {
  // Khmer language competencies
  listening?: number; // សមត្ថភាពស្តាប់
  writing?: number; // សមត្ថភាពសរសេរ
  reading?: number; // សមត្ថភាពអាន
  speaking?: number; // សមត្ថភាពនិយាយ
  khmerReading?: number; // អំណាន (Legacy compatibility)
  khmerWriting?: number; // សំណេរ (Legacy compatibility)

  // Mathematics competencies
  numbers?: number; // ចំនួន
  measurement?: number; // រង្វាស់រង្វាល់
  geometry?: number; // ធរណីមាត្រ
  algebra?: number; // ពីជគណិត
  statistics?: number; // ស្ថិតិ
  mathematics?: number; // គណិតវិទ្យា (Legacy compatibility)

  // Sciences, Social & Morals
  science?: number; // វិទ្យាសាស្ត្រ
  socialStudies?: number; // សិក្សាសង្គម
  moralCivics?: number; // សីលធម៌-ពលរដ្ឋវិជ្ជា
  scienceSocial?: number; // វិទ្យាសាស្ត្រ និងសិក្សាសង្គម (Legacy)

  // Arts, PE & Life Skills
  homeEconomicsArts?: number; // គេហកិច្ច-អប់រំសិល្បៈ
  physicalHealth?: number; // អប់រំកាយ-កីឡាសុខភាព-អនាម័យ
  lifeSkills?: number; // អប់រំបំណិនជីវិត
  foreignLanguage?: number; // ភាសាបរទេស
  artsPhysical?: number; // សិល្បៈ និងកាយវិការ (Legacy)

  // Dynamic custom subjects
  [key: string]: number | undefined;
}

export interface StudentScoreRecord {
  id: string;
  studentId: string;
  studentCode: string;
  studentNameKhmer: string;
  gender: Gender;
  grade: number;
  section: string;
  monthOrSemester: string; // 'តុលា', 'វិច្ឆិកា', 'ធ្នូ', 'មករា', 'កុម្ភៈ', 'មីនា', 'មេសា', 'ឧសភា', 'មិថុនា', 'កក្កដា', 'ឆមាសទី១', 'ឆមាសទី២'
  academicYear: string;
  scores: MonthlySubjectScores;
  totalScore: number;
  averageScore: number;
  rank: number;
  gradeLetter: 'A' | 'B' | 'C' | 'D' | 'E' | 'F';
  resultStatus: 'ជាប់' | 'ធ្លាក់';
  remarks?: string;
}

export interface DailyAttendanceRecord {
  id: string;
  date: string; // YYYY-MM-DD
  grade: number;
  section: string;
  studentId: string;
  studentNameKhmer: string;
  status: 'present' | 'permission' | 'absent';
  session: 'morning' | 'afternoon';
  notes?: string;
}

export type BudgetSource = 
  | 'ថវិការដ្ឋ (PB)'
  | 'សហគមន៍/សមាគមមាតាបិតា'
  | 'ដៃគូអភិវឌ្ឍន៍/NGO'
  | 'មូលនិធិកែលម្អសាលា (SIG)'
  | 'ចំណូលផ្សេងៗ';

export interface BudgetTransaction {
  id: string;
  title: string;
  type: 'income' | 'expense';
  source: BudgetSource;
  category: string; // e.g., 'សម្ភារៈឧបទេស', 'ជួសជុលអគារ', 'អនាម័យនិងទឹកស្អាត', 'បណ្ណាល័យ', 'កីឡា'
  amountRiel: number;
  amountUsd: number;
  date: string;
  referenceCode: string;
  recordedBy: string;
  description?: string;
  status: 'approved' | 'pending';
}

export type GradingScaleType = 'khmer_term' | 'letter';

export interface SchoolProfile {
  nameKhmer: string;
  nameLatin: string;
  schoolCode: string;
  province: string;
  district: string;
  commune: string;
  village: string;
  principalName: string;
  principalPhone: string;
  deputyPrincipalName: string;
  academicYear: string;
  establishedYear: string;
  cluster: string;
  email: string;
  logoUrl?: string;
  mapUrl?: string;
  facebookPage?: string;
  gradingScaleType?: GradingScaleType; // 'khmer_term' (ល្អណាស់, ល្អ, ល្អបង្គួរ...) vs 'letter' (A, B, C...)
}

export type CalendarEventType = 'exam' | 'holiday' | 'vacation' | 'meeting' | 'ceremony' | 'academic';

export interface AcademicCalendarEvent {
  id: string;
  titleKhmer: string;
  titleLatin?: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  type: CalendarEventType;
  description?: string;
  targetGrades?: string; // e.g. "ថ្នាក់ទី១ ដល់ ទី៦", "ថ្នាក់ទី៦", "លោកគ្រូ-អ្នកគ្រូ"
  isOfficialHoliday?: boolean;
  location?: string;
  googleCalendarEventId?: string;
  isSyncedToGoogle?: boolean;
}

export type UserRole = 
  | 'director'    // នាយកសាលារៀន
  | 'secretary'   // លេខាធិការ
  | 'librarian'   // បណ្ណារក្ស
  | 'teacher'     // គ្រូបង្រៀន / គ្រូបន្ទុកថ្នាក់
  | 'student';    // សិស្ស

export interface AppUser {
  id: string;
  username: string;
  email: string;
  password?: string;
  nameKhmer: string;
  nameLatin?: string;
  role: UserRole;
  phone?: string;
  staffCode?: string; // For teachers/staff
  studentId?: string; // For students
  studentCode?: string; // For students STU-2024-xxx
  assignedGrade?: number;
  assignedSection?: string;
  avatarUrl?: string;
  createdBy?: string;
  createdAt: string;
  status: 'active' | 'suspended';
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'password_reset' | 'info' | 'alert' | 'system';
  targetRole?: UserRole | 'all';
  targetUserId?: string;
  targetTeacherGrade?: number;
  targetTeacherSection?: string;
  read: boolean;
  meta?: {
    studentId?: string;
    studentName?: string;
    actionTime?: string;
  };
}

export type ActiveTab = 
  | 'dashboard'
  | 'students'
  | 'transfers'
  | 'household_census'
  | 'teachers'
  | 'classrooms'
  | 'scores'
  | 'attendance_health'
  | 'library'
  | 'calendar'
  | 'finance'
  | 'reports_qr'
  | 'accounts'
  | 'student_portal'
  | 'workspace'
  | 'settings';

export interface FamilyMember {
  id: string;
  name: string;
  gender: Gender;
  dob: string;
  age: number;
  relationship: string; // កូន, ឪពុក, ម្តាយ, ជីដូន, ជីតា, ក្មួយ, ...
  occupation: string;
  nationalId?: string;
  civilStatusDoc?: string; // សំបុត្រកំណើត / សំបុត្រអាពាហ៍ពិពាហ៍ / សៀវភៅស្នាក់នៅ
  otherDoc?: string;
  isStudentAtSchool?: boolean;
  studentGrade?: number;
  studentSection?: string;
  studentCode?: string;
}

export interface HouseholdRecord {
  id: string;
  houseNumber: string; // លេខខ្នងផ្ទះ
  village: string; // ភូមិ
  commune: string; // ឃុំ
  district: string; // ស្រុក
  province: string; // ខេត្ត
  censusDate: string; // កាលបរិច្ឆេទជំរឿន (YYYY-MM-DD)
  academicYear: string; // ឆ្នាំសិក្សា
  
  // GPS Coordinates (ទីតាំងផ្ទះ)
  lat: number;
  lng: number;
  gpsAccuracy?: number;
  
  // Photos
  housePhotoUrl?: string; // រូបថតផ្ទះ
  familyBookPhotoUrl?: string; // រូបថតសៀវភៅគ្រួសារ
  equityCardPhotoUrl?: string; // រូបថតបណ្ណសមធម៌
  
  // Head of Family & Spouse
  headName: string; // ឈ្មោះមេគ្រួសារ
  headGender: Gender;
  headOccupation: string;
  headNationalId?: string;
  
  spouseName?: string; // ឈ្មោះសហព័ទ្ធ
  spouseGender?: Gender;
  spouseOccupation?: string;
  
  // House characteristics & social status
  houseType: string; // ប្រភេទផ្ទះ (ផ្ទះឈើលើថ្មក្រោម, ផ្ទះថ្ម, ផ្ទះឈើប្រក់ក្បឿង, ផ្ទះស័ង្កសី...)
  currentAddress: string; // លំនៅបច្ចុប្បន្ន
  familyStatus: 'ទូទៅ' | 'ក្រ១' | 'ក្រ២' | 'ងាយរងគ្រោះ'; // ស្ថានភាពគ្រួសារ
  equityCardNumber?: string; // លេខបណ្ណសមធម៌
  phoneNumber: string; // លេខទូរស័ព្ទ
  
  // Members List (Up to 10 members)
  members: FamilyMember[];
  
  remarks?: string; // ផ្សេងៗ
  recordedBy?: string; // អ្នកកត់ត្រា
}

export type FamilyPovertyStatus = 'ទូទៅ' | 'ក្រ១' | 'ក្រ២' | 'ងាយរងគ្រោះ' | 'ងាយរងហានិភ័យ';

export type LibraryBookCategory = 'storybook' | 'core_textbook' | 'reference' | 'magazine' | 'general';

export type StudentScore = StudentScoreRecord;

export interface LibraryBook {
  id: string;
  code: string; // កូដសៀវភៅ
  titleKhmer: string; // ចំណងជើងសៀវភៅ
  titleLatin?: string;
  category: LibraryBookCategory; // សៀវភៅរឿងនិទាន | សៀវភៅពុម្ពគោល | ឯកសារយោង
  author: string; // អ្នកនិពន្ធ / ក្រសួងអប់រំ
  publisher?: string;
  publishedYear?: string;
  targetGrade?: number; // សម្រាប់ថ្នាក់ទី ១-៦
  gradeLevel?: number;
  totalCopies: number; // ចំនួនសរុប
  availableCopies: number; // ចំនួននៅសល់
  coverUrl?: string;
  coverPhotoUrl?: string;
  shelfLocation?: string; // ទីតាំងទូ/ធ្នើ
  description?: string;
  notes?: string;
}

export interface LibraryReadingLog {
  id: string;
  studentId: string;
  studentCode: string;
  studentNameKhmer: string;
  grade: number;
  section: string;
  bookId: string;
  bookTitle: string;
  bookCategory: string;
  borrowDate: string;
  dueDate: string;
  returnDate?: string;
  status: 'borrowed' | 'returned' | 'overdue';
  pagesRead?: number;
  readingSummary?: string; // សង្ខេបខ្លឹមសាររឿងដែលបានអាន
  teacherLibrarianSign?: string;
}

export interface PrintSettings {
  includeRoundStamp: boolean; // ត្រាមូលសាលា
  includeDirectorSignature: boolean; // ហត្ថលេខានាយក
  redDirectorName: boolean; // ឈ្មោះនាយកពណ៌ក្រហម
  showRoundStamp?: boolean;
  showDirectorSignature?: boolean;
  showDirectorRedName?: boolean;
  showWatermark?: boolean;
}

export interface GoogleUserInfo {
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  uid: string;
}

