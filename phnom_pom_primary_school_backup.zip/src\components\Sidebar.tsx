import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { ActiveTab, UserRole } from '../types';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  School,
  BookOpen,
  CalendarCheck,
  Calendar,
  CircleDollarSign,
  FileSpreadsheet,
  HardDrive,
  Settings,
  MapPin,
  Phone,
  Facebook,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  X,
  User as UserIcon,
  ShieldCheck,
  LogIn,
  LogOut,
  Shield,
  Award,
  ArrowRightLeft,
  Home,
  Library as LibraryIcon,
  BookMarked
} from 'lucide-react';
import { User } from 'firebase/auth';

interface SidebarProps {
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
  onOpenSettings: () => void;
  googleUser: User | null;
  onGoogleAuthClick: () => void;
  isAuthLoading: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isMobileOpen,
  setIsMobileOpen,
  isCollapsed,
  setIsCollapsed,
  onOpenSettings,
  googleUser,
  onGoogleAuthClick,
  isAuthLoading,
}) => {
  const {
    activeTab,
    setActiveTab,
    schoolProfile,
    students,
    teachers,
    classrooms,
    transfers,
    households,
    libraryBooks,
    currentUser,
    canAccessTab,
    appUsers,
    language
  } = useSchool();

  const allNavItems: {
    id: ActiveTab;
    labelKh: string;
    labelEn: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number | string;
    badgeColor?: string;
  }[] = [
    {
      id: 'dashboard',
      labelKh: 'ផ្ទាំងគ្រប់គ្រងទូទៅ',
      labelEn: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'student_portal',
      labelKh: 'គណនីសិស្សផ្ទាល់ខ្លួន',
      labelEn: 'Student Portal',
      icon: GraduationCap,
      badge: 'STU',
      badgeColor: 'bg-purple-100 text-purple-700 font-bold',
    },
    {
      id: 'students',
      labelKh: 'គ្រប់គ្រងសិស្សានុសិស្ស',
      labelEn: 'Student Directory',
      icon: Users,
      badge: students.length,
      badgeColor: 'bg-blue-100 text-blue-700 font-semibold',
    },
    {
      id: 'transfers',
      labelKh: 'ការផ្ទេរសិស្ស (MoEYS)',
      labelEn: 'Student Transfers',
      icon: ArrowRightLeft,
      badge: transfers.length,
      badgeColor: 'bg-amber-100 text-amber-800 font-semibold',
    },
    {
      id: 'household_census',
      labelKh: 'ជំរឿនផែនទីខ្នងផ្ទះ',
      labelEn: 'Household Census & Map',
      icon: Home,
      badge: households.length,
      badgeColor: 'bg-emerald-100 text-emerald-800 font-semibold',
    },
    {
      id: 'library',
      labelKh: 'បណ្ណាល័យ & សៀវភៅ',
      labelEn: 'Library & Reading',
      icon: LibraryIcon,
      badge: libraryBooks.length,
      badgeColor: 'bg-teal-100 text-teal-800 font-semibold',
    },
    {
      id: 'teachers',
      labelKh: 'គ្រូបង្រៀន & បុគ្គលិក',
      labelEn: 'Teaching Staff',
      icon: GraduationCap,
      badge: teachers.length,
      badgeColor: 'bg-indigo-100 text-indigo-700 font-semibold',
    },
    {
      id: 'classrooms',
      labelKh: 'បន្ទប់ & ថ្នាក់រៀន',
      labelEn: 'Classrooms',
      icon: School,
      badge: classrooms.length,
      badgeColor: 'bg-slate-100 text-slate-700',
    },
    {
      id: 'scores',
      labelKh: 'ស្រង់ពិន្ទុ & ចំណាត់ថ្នាក់',
      labelEn: 'Academic Scores',
      icon: BookOpen,
    },
    {
      id: 'attendance_health',
      labelKh: 'វត្តមាន & សុខភាព (BMI)',
      labelEn: 'Attendance & Health',
      icon: CalendarCheck,
    },
    {
      id: 'calendar',
      labelKh: 'ប្រតិទិនសិក្សា & ការប្រឡង',
      labelEn: 'Academic Calendar',
      icon: Calendar,
      badge: 'MoEYS',
      badgeColor: 'bg-rose-100 text-rose-700 font-semibold',
    },
    {
      id: 'finance',
      labelKh: 'ថវិកា & ហិរញ្ញវត្ថុ',
      labelEn: 'Budget & Finance',
      icon: CircleDollarSign,
    },
    {
      id: 'reports_qr',
      labelKh: 'របាយការណ៍ & QR កាត',
      labelEn: 'MoEYS Reports & QR',
      icon: FileSpreadsheet,
    },
    {
      id: 'accounts',
      labelKh: 'គ្រប់គ្រងគណនី & RBAC',
      labelEn: 'Accounts & Security',
      icon: Shield,
      badge: appUsers.length,
      badgeColor: 'bg-emerald-100 text-emerald-700 font-bold',
    },
    {
      id: 'workspace',
      labelKh: 'Google Workspace Hub',
      labelEn: 'Sheets & Drive Sync',
      icon: HardDrive,
      badge: googleUser ? 'ភ្ជាប់រួច' : 'Google',
      badgeColor: googleUser ? 'bg-emerald-100 text-emerald-700 font-semibold' : 'bg-amber-100 text-amber-800',
    },
  ];

  // Filter navigation items strictly based on currentUser's RBAC permissions
  const filteredNavItems = allNavItems.filter(item => canAccessTab(item.id));

  const handleNavClick = (tabId: ActiveTab) => {
    setActiveTab(tabId);
    setIsMobileOpen(false);
  };

  const getRoleLabel = (role?: UserRole) => {
    if (language === 'en') {
      switch (role) {
        case 'director': return 'Director';
        case 'secretary': return 'Secretary';
        case 'librarian': return 'Librarian';
        case 'teacher': return 'Teacher';
        case 'student': return 'Student';
        default: return 'User';
      }
    }
    switch (role) {
      case 'director': return 'នាយកសាលា';
      case 'secretary': return 'លេខាធិការ';
      case 'librarian': return 'បណ្ណារក្ស';
      case 'teacher': return 'គ្រូបង្រៀន';
      case 'student': return 'សិស្សានុសិស្ស';
      default: return 'អ្នកប្រើប្រាស់';
    }
  };

  const content = (
    <div className="flex flex-col h-full bg-slate-900 text-slate-200 select-none font-battambang">
      {/* Top Emblem & Brand */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-950/60 relative">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-500 p-0.5 shadow-md flex-shrink-0 flex items-center justify-center text-white">
              <School className="w-5 h-5" />
            </div>
            {!isCollapsed && (
              <div className="min-w-0 flex-1">
                <h1 className="text-sm font-bold font-moul text-amber-300 truncate leading-tight">
                  {language === 'en' ? (schoolProfile.nameLatin || schoolProfile.nameKhmer) : schoolProfile.nameKhmer}
                </h1>
                <p className="text-[11px] text-slate-400 font-medium truncate font-times">
                  {language === 'en' ? schoolProfile.nameKhmer : schoolProfile.nameLatin}
                </p>
              </div>
            )}
          </div>

          {/* Close button on mobile / Collapse on desktop */}
          <div className="flex items-center">
            <button
              onClick={() => setIsMobileOpen(false)}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              aria-label={language === 'en' ? 'Close Menu' : 'បិទម៉ឺនុយ'}
            >
              <X className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title={isCollapsed ? (language === 'en' ? 'Expand sidebar' : 'ពង្រីកម៉ឺនុយ') : (language === 'en' ? 'Collapse sidebar' : 'បង្រួមម៉ឺនុយ')}
            >
              {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Academic year badge */}
        {!isCollapsed && (
          <div className="mt-3 flex items-center justify-between text-[11px] bg-slate-800/70 rounded-lg px-2.5 py-1 text-slate-300 border border-slate-700/50">
            <span className="text-amber-400 font-semibold">
              {language === 'en' ? `Academic Year ${schoolProfile.academicYear}` : `ឆ្នាំសិក្សា ${schoolProfile.academicYear}`}
            </span>
            <span className="text-slate-400 font-times">
              {language === 'en' ? `Code: ${schoolProfile.schoolCode}` : `កូដ: ${schoolProfile.schoolCode}`}
            </span>
          </div>
        )}
      </div>

      {/* School Contact & Links Card (Expanded view) */}
      {!isCollapsed && (
        <div className="p-3 mx-3 my-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs text-slate-300 space-y-2">
          <div className="flex items-start gap-2">
            <MapPin className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="text-[11px] leading-snug">
              <span className="text-slate-200 font-medium">{schoolProfile.village}, {schoolProfile.commune}</span>
              <p className="text-slate-400">{schoolProfile.district}, {schoolProfile.province}</p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1.5 border-t border-slate-700/50 text-[11px]">
            <div className="flex items-center gap-1.5">
              <UserIcon className="w-3.5 h-3.5 text-blue-400" />
              <span>
                {language === 'en' ? 'Principal: ' : 'នាយក: '}
                <strong className="text-white font-medium">{schoolProfile.principalName}</strong>
              </span>
            </div>
            <a
              href={`tel:${schoolProfile.principalPhone.replace(/\s+/g, '')}`}
              className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-times font-medium"
              title={language === 'en' ? 'Click to call' : 'ចុចដើម្បីទូរស័ព្ទ'}
            >
              <Phone className="w-3 h-3" />
              <span>{schoolProfile.principalPhone}</span>
            </a>
          </div>

          {/* Social & Maps Action Links */}
          <div className="grid grid-cols-2 gap-1.5 pt-1">
            {schoolProfile.mapUrl && (
              <a
                href={schoolProfile.mapUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-1 px-2 py-1 bg-blue-600/30 hover:bg-blue-600/50 border border-blue-500/40 rounded-lg text-[10px] text-blue-300 hover:text-white transition-colors"
              >
                <MapPin className="w-3 h-3 text-red-400" />
                <span>Google Maps</span>
                <ExternalLink className="w-2.5 h-2.5 opacity-70" />
              </a>
            )}
            {schoolProfile.facebookPage && (
              <a
                href={schoolProfile.facebookPage}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-1 px-2 py-1 bg-sky-600/30 hover:bg-sky-600/50 border border-sky-500/40 rounded-lg text-[10px] text-sky-300 hover:text-white transition-colors"
              >
                <Facebook className="w-3 h-3 text-sky-400" />
                <span>Facebook</span>
                <ExternalLink className="w-2.5 h-2.5 opacity-70" />
              </a>
            )}
          </div>
        </div>
      )}

      {/* Navigation Links (Vertical List) */}
      <div className="flex-1 overflow-y-auto px-2.5 py-2 space-y-1 custom-scrollbar">
        <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          {!isCollapsed ? (language === 'en' ? `Role: ${getRoleLabel(currentUser?.role)}` : `សិទ្ធិ: ${getRoleLabel(currentUser?.role)}`) : '•••'}
        </div>

        {filteredNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          const primaryTitle = language === 'en' ? item.labelEn : item.labelKh;
          const secondaryTitle = language === 'en' ? item.labelKh : item.labelEn;

          return (
            <button
              key={item.id}
              id={`sidebar-nav-${item.id}`}
              onClick={() => handleNavClick(item.id)}
              title={isCollapsed ? primaryTitle : undefined}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs transition-all duration-150 relative ${
                isActive
                  ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-900/40'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white font-medium'
              } ${isCollapsed ? 'justify-center px-2' : 'justify-between'}`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                {!isCollapsed && (
                  <div className="text-left min-w-0 truncate">
                    <span className="truncate block leading-tight font-medium">{primaryTitle}</span>
                    <span className="text-[10px] text-slate-400 font-normal block leading-none font-times">{secondaryTitle}</span>
                  </div>
                )}
              </div>

              {!isCollapsed && item.badge !== undefined && (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-times ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                  {item.badge}
                </span>
              )}

              {/* Active Indicator Bar */}
              {isActive && (
                <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-amber-400 rounded-r-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom Footer Section: Google Workspace Auth & Settings */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/80 space-y-2">
        {/* Google Workspace Quick Status */}
        {!isCollapsed ? (
          <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${googleUser ? 'bg-emerald-600/20 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                <HardDrive className="w-4 h-4" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[11px] font-semibold text-slate-200 truncate">
                  {googleUser ? (googleUser.displayName || 'Google Account') : 'Google Workspace'}
                </p>
                <p className="text-[10px] text-slate-400 truncate">
                  {googleUser ? (googleUser.email || (language === 'en' ? 'Connected' : 'ភ្ជាប់រួចរាល់')) : 'Drive & Sheets Sync'}
                </p>
              </div>
            </div>
            <button
              onClick={onGoogleAuthClick}
              disabled={isAuthLoading}
              className={`p-1.5 rounded-lg text-xs transition-colors ${
                googleUser
                  ? 'text-rose-400 hover:bg-rose-500/20'
                  : 'bg-blue-600 hover:bg-blue-700 text-white font-medium px-2 py-1 text-[11px]'
              }`}
              title={googleUser ? (language === 'en' ? 'Disconnect Google Account' : 'ផ្ដាច់គណនី Google') : (language === 'en' ? 'Connect Google Account' : 'ភ្ជាប់ Google Account')}
            >
              {isAuthLoading ? (
                '...'
              ) : googleUser ? (
                <LogOut className="w-3.5 h-3.5" />
              ) : (
                <span className="flex items-center gap-1"><LogIn className="w-3 h-3" /> {language === 'en' ? 'Connect' : 'ភ្ជាប់'}</span>
              )}
            </button>
          </div>
        ) : (
          <button
            onClick={onGoogleAuthClick}
            className={`w-full py-2 flex items-center justify-center rounded-xl transition-colors ${googleUser ? 'text-emerald-400 hover:bg-slate-800' : 'text-slate-400 hover:bg-slate-800'}`}
            title={googleUser ? `Google: ${googleUser.email}` : (language === 'en' ? 'Connect Google' : 'ភ្ជាប់ Google')}
          >
            <HardDrive className="w-4 h-4" />
          </button>
        )}

        {/* Settings button */}
        {canAccessTab('settings') && (
          <button
            id="sidebar-settings-btn"
            onClick={() => {
              onOpenSettings();
              setIsMobileOpen(false);
            }}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-slate-300 hover:bg-slate-800 hover:text-white font-medium transition-colors ${
              isCollapsed ? 'justify-center px-2' : ''
            }`}
            title={language === 'en' ? 'School Settings' : 'កំណត់ព័ត៌មានសាលារៀន'}
          >
            <Settings className="w-4 h-4 text-slate-400 flex-shrink-0" />
            {!isCollapsed && <span>{language === 'en' ? 'School Settings' : 'ការកំណត់ព័ត៌មានសាលា'}</span>}
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop & Tablet Sidebar (Left fixed) */}
      <aside
        className={`hidden lg:flex flex-col flex-shrink-0 border-r border-slate-800 bg-slate-900 h-screen sticky top-0 transition-all duration-300 z-30 ${
          isCollapsed ? 'w-16' : 'w-64 xl:w-72'
        }`}
      >
        {content}
      </aside>

      {/* Mobile Slide-over Drawer (Phone & Small Tablet) */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Overlay backdrop */}
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
            onClick={() => setIsMobileOpen(false)}
          />

          {/* Drawer content */}
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-slate-900 h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
