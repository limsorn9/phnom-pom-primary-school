import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  GraduationCap,
  Award,
  BookOpen,
  CalendarCheck,
  Calendar,
  Heart,
  QrCode,
  Lock,
  User,
  School,
  Sparkles,
  CheckCircle2,
  Printer
} from 'lucide-react';

export const StudentPortal: React.FC = () => {
  const {
    currentUser,
    students,
    scores,
    attendanceRecords,
    calendarEvents,
    schoolProfile,
    updateUser,
    showToast,
    isResultReleased,
    getFormattedGrade
  } = useSchool();

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Find linked student record
  const studentData = students.find(
    s =>
      (currentUser?.studentCode && s.code === currentUser.studentCode) ||
      (currentUser?.studentId && s.id === currentUser.studentId) ||
      s.code === 'STU-2024-001'
  ) || students[0];

  // Find scores for this student
  const studentScores = scores.filter(sc => sc.studentId === studentData?.id);
  const latestScore = studentScores.length > 0 ? studentScores[studentScores.length - 1] : null;

  // Student Attendance
  const studentAttendance = attendanceRecords.filter(a => a.studentId === studentData?.id);
  const presentCount = studentAttendance.filter(a => a.status === 'present').length;
  const permissionCount = studentAttendance.filter(a => a.status === 'permission').length;
  const absentCount = studentAttendance.filter(a => a.status === 'absent').length;

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword !== confirmPassword) {
      showToast('ពាក្យសម្ងាត់ទាំងពីរមិនដូចគ្នាទេ!', 'error');
      return;
    }
    if (currentUser) {
      updateUser(currentUser.id, { password: newPassword });
      setShowPasswordModal(false);
      setNewPassword('');
      setConfirmPassword('');
      showToast('បានផ្លាស់ប្តូរពាក្យសម្ងាត់ជោគជ័យ!');
    }
  };

  const handlePrintCard = () => {
    window.print();
  };

  return (
    <div className="space-y-6 font-battambang">
      {/* Student Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-800 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-64 h-64 bg-white/5 rounded-full blur-2xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-18 h-18 rounded-2xl bg-white/10 border-2 border-white/20 p-1 backdrop-blur-xs flex items-center justify-center shrink-0">
              {studentData?.avatarUrl ? (
                <img
                  src={studentData.avatarUrl}
                  alt={studentData.nameKhmer}
                  className="w-full h-full object-cover rounded-xl"
                />
              ) : (
                <GraduationCap className="w-10 h-10 text-white/80" />
              )}
            </div>

            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/30 border border-blue-400/30 text-blue-200 text-xs font-semibold mb-1">
                <Sparkles className="w-3 h-3 text-amber-300" />
                គណនីសិស្សានុសិស្ស (Student Portal)
              </div>
              <h2 className="font-moul text-xl sm:text-2xl text-white tracking-wide">
                {studentData?.nameKhmer || currentUser?.nameKhmer}
              </h2>
              <p className="text-xs text-blue-200 mt-1 font-times font-medium">
                អត្តលេខ: <span className="font-bold text-white">{studentData?.code}</span> • ថ្នាក់ទី {studentData?.grade}{studentData?.section} • ឆ្នាំសិក្សា {schoolProfile.academicYear}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowPasswordModal(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold transition-all"
            >
              <Lock className="w-4 h-4" />
              <span>ប្តូរពាក្យសម្ងាត់</span>
            </button>

            <button
              type="button"
              onClick={handlePrintCard}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-900 text-xs font-bold shadow-md transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>បោះពុម្ពប័ណ្ណសិស្ស</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold mb-2">
            <span>និទ្ទេសចុងក្រោយ</span>
            <Award className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-times font-bold text-slate-800">
            {latestScore ? `និទ្ទេស ${latestScore.gradeLetter}` : 'និទ្ទេស A'}
          </p>
          <p className="text-[11px] text-emerald-600 font-semibold mt-1">
            {latestScore ? `មធ្យមភាគ ${latestScore.averageScore} / 10` : 'មធ្យមភាគ 8.65 / 10'}
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold mb-2">
            <span>ចំណាត់ថ្នាក់ក្នុងថ្នាក់</span>
            <Sparkles className="w-4 h-4 text-purple-600" />
          </div>
          <p className="text-2xl font-times font-bold text-purple-700">
            {latestScore ? `លេខ ${latestScore.rank}` : 'លេខ ១'}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            ក្នុងចំណោមសិស្ស {students.filter(s => s.grade === studentData?.grade).length} នាក់
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold mb-2">
            <span>វត្តមានសិក្សា</span>
            <CalendarCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-times font-bold text-emerald-700">
            {presentCount > 0 ? `${presentCount} ថ្ងៃ` : '៩៨%'}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            អវត្តមានមានច្បាប់ {permissionCount} ថ្ងៃ
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold mb-2">
            <span>សុខភាព & អាហារូបត្ថម្ភ</span>
            <Heart className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-lg font-bold text-slate-800">
            {studentData?.health?.nutritionStatus === 'normal' ? 'សុខភាពល្អ' : 'ធម្មតា'}
          </p>
          <p className="text-[11px] text-slate-500 font-times mt-1">
            BMI: {studentData?.health?.bmi || '16.8'} (កម្ពស់ {studentData?.health?.heightCm}cm)
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Academic Scores Table */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-700" />
                <h3 className="font-moul text-sm text-slate-800">លទ្ធផលសិក្សា & ព្រឹត្តិបត្រពិន្ទុ</h3>
              </div>
              <span className="text-xs text-slate-500 font-times">កម្រិតថ្នាក់ទី {studentData?.grade}</span>
            </div>

            {studentScores.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold uppercase">
                    <tr>
                      <th className="px-3 py-2.5">ខែ / ឆមាស</th>
                      <th className="px-2 py-2.5 text-center font-times">អំណាន</th>
                      <th className="px-2 py-2.5 text-center font-times">សំណេរ</th>
                      <th className="px-2 py-2.5 text-center font-times">គណិត</th>
                      <th className="px-2 py-2.5 text-center font-times">វិទ្យាសាស្ត្រ</th>
                      <th className="px-2 py-2.5 text-center font-times">សីលធម៌</th>
                      <th className="px-2 py-2.5 text-center font-times">សិល្បៈ</th>
                      <th className="px-3 py-2.5 text-center font-times">មធ្យមភាគ</th>
                      <th className="px-2 py-2.5 text-center font-times">និទ្ទេស</th>
                      <th className="px-2 py-2.5 text-center font-times">ចំណាត់ថ្នាក់</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-times">
                    {studentScores.map(sc => (
                      <tr key={sc.id} className="hover:bg-slate-50/80">
                        <td className="px-3 py-2.5 font-battambang font-bold text-slate-800">
                          {sc.monthOrSemester}
                        </td>
                        <td className="px-2 py-2.5 text-center">{sc.scores.khmerReading}</td>
                        <td className="px-2 py-2.5 text-center">{sc.scores.khmerWriting}</td>
                        <td className="px-2 py-2.5 text-center font-bold text-blue-700">
                          {sc.scores.mathematics}
                        </td>
                        <td className="px-2 py-2.5 text-center">{sc.scores.scienceSocial}</td>
                        <td className="px-2 py-2.5 text-center">{sc.scores.moralCivics}</td>
                        <td className="px-2 py-2.5 text-center">{sc.scores.artsPhysical}</td>
                        <td className="px-3 py-2.5 text-center font-bold text-slate-900">
                          {sc.averageScore}
                        </td>
                        <td className="px-2 py-2.5 text-center">
                          <span className="px-2 py-0.5 rounded-md font-bold text-[11px] bg-blue-100 text-blue-800">
                            {getFormattedGrade(sc.averageScore, sc.gradeLetter)}
                          </span>
                        </td>
                        <td className="px-2 py-2.5 text-center font-bold text-purple-700">
                          លេខ {sc.rank}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-8 text-center text-slate-400 text-xs">
                ពុំទាន់មានទិន្នន័យស្រង់ពិន្ទុសម្រាប់សិស្សនេះនៅឡើយ
              </div>
            )}
          </div>

          {/* Upcoming Exams & Events */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-5 h-5 text-indigo-700" />
              <h3 className="font-moul text-sm text-slate-800">កាលវិភាគប្រឡង & ព្រឹត្តិការណ៍សិក្សា</h3>
            </div>

            <div className="space-y-3">
              {calendarEvents.slice(0, 4).map(evt => (
                <div
                  key={evt.id}
                  className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-start justify-between gap-3"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">{evt.titleKhmer}</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">{evt.description || 'ព្រឹត្តិការណ៍តាមប្រតិទិន MoEYS'}</p>
                    <p className="text-[11px] text-blue-700 font-times font-semibold mt-1">
                      កាលបរិច្ឆេទ: {evt.startDate} ដល់ {evt.endDate}
                    </p>
                  </div>
                  <span className="px-2 py-1 rounded-lg text-[10px] font-bold uppercase bg-blue-100 text-blue-800 shrink-0">
                    {evt.type}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Digital Student ID Card */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs text-center">
            <div className="flex items-center justify-between mb-3 text-xs text-slate-500 font-bold">
              <span>ប័ណ្ណសម្គាល់ខ្លួនសិស្ស (Student Card)</span>
              <QrCode className="w-4 h-4 text-blue-700" />
            </div>

            {/* Official ID Card Layout */}
            <div className="border-2 border-blue-900 rounded-2xl p-4 bg-gradient-to-b from-blue-50/50 to-white text-left space-y-3 shadow-inner">
              <div className="text-center border-b border-blue-200 pb-2">
                <p className="font-moul text-[10px] text-blue-950">{schoolProfile.nameKhmer}</p>
                <p className="text-[9px] text-slate-600">ប័ណ្ណសម្គាល់ខ្លួនសិស្ស • Student Card</p>
              </div>

              <div className="flex gap-3 items-center">
                <div className="w-16 h-20 bg-slate-200 rounded-lg overflow-hidden border border-slate-300 shrink-0 flex items-center justify-center">
                  {studentData?.avatarUrl ? (
                    <img
                      src={studentData.avatarUrl}
                      alt={studentData.nameKhmer}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="w-8 h-8 text-slate-400" />
                  )}
                </div>

                <div className="text-xs space-y-0.5 text-slate-800">
                  <p className="font-bold text-blue-950">{studentData?.nameKhmer}</p>
                  <p className="font-times text-[11px] text-slate-600">{studentData?.nameLatin}</p>
                  <p className="text-[11px]">ភេទ: <span className="font-bold">{studentData?.gender === 'M' ? 'ប្រុស' : 'ស្រី'}</span></p>
                  <p className="text-[11px]">ថ្នាក់ទី: <span className="font-bold text-blue-700">{studentData?.grade}{studentData?.section}</span></p>
                  <p className="font-times text-[10.5px] font-bold text-purple-700">ID: {studentData?.code}</p>
                </div>
              </div>

              {/* QR Code Demo Box */}
              <div className="bg-slate-100 rounded-xl p-2.5 flex items-center justify-between border border-slate-200 text-center">
                <div className="w-12 h-12 bg-white rounded-lg border border-slate-300 p-1 flex items-center justify-center">
                  <QrCode className="w-full h-full text-slate-800" />
                </div>
                <div className="text-right text-[10px] text-slate-500">
                  <p className="font-times font-bold text-slate-800">{schoolProfile.academicYear}</p>
                  <p>ស្កេនដើម្បីផ្ទៀងផ្ទាត់</p>
                </div>
              </div>
            </div>

            <div className="mt-4">
              <button
                type="button"
                onClick={handlePrintCard}
                className="w-full py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>បោះពុម្ពប័ណ្ណសម្គាល់ខ្លួន</span>
              </button>
            </div>
          </div>

          {/* Guardian Info */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs text-xs space-y-2 text-slate-700">
            <h4 className="font-bold text-slate-900 border-b border-slate-100 pb-2">ព័ត៌មានអាណាព្យាបាល</h4>
            <p>ឈ្មោះ: <span className="font-semibold text-slate-900">{studentData?.guardianName}</span> ({studentData?.guardianRelationship})</p>
            <p>លេខទូរស័ព្ទ: <span className="font-times font-semibold text-blue-700">{studentData?.guardianPhone}</span></p>
            <p>មុខរបរ: {studentData?.guardianOccupation}</p>
            <p>អាសយដ្ឋាន: {studentData?.address}</p>
          </div>
        </div>
      </div>

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                  <Lock className="w-5 h-5" />
                </div>
                <h3 className="font-moul text-sm text-slate-800">ប្តូរពាក្យសម្ងាត់គណនី</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowPasswordModal(false)}
                className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handlePasswordChange} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ពាក្យសម្ងាត់ថ្មី</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="បញ្ចូលពាក្យសម្ងាត់ថ្មី"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-times focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">បញ្ជាក់ពាក្យសម្ងាត់ថ្មី</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="វាយពាក្យសម្ងាត់ម្តងទៀត"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-times focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  បោះបង់
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-xl shadow-xs"
                >
                  រក្សាទុកពាក្យសម្ងាត់
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
